//Olga Osinskaya
//Assignment#1

//variables for statistic
var compWinner=0;
var userWinner=0;
var tie=0;
var word;//keep definition for computer choose

//main function - provides all logic
function myFunction() {

  //generate a random number in the range 0 through 1
  var randomNums = Math.random();

  //toWord function translates computer choose to words
  function toWord(randomNum) {
    if (randomNum >= 0 && randomNum <= 0.33) {
      word = "rock";
    } else if (randomNum >= 0.34 && randomNum <= 0.66) {
      word = "paper";
    } else {
      word = "scissors";
    }
    return word;
  }

  //call toWord function and pass randomNums as argument
  computerChoose = toWord(randomNums);

  //userChoose gets value from user and helds it
  var userChoose = document.getElementById("userChooseValue").value;

/*
  the toLowerCase() method converts a string to lowercase letters.
  the trim() method removes characters from both ends.
*/
  userChoose = userChoose.toLowerCase().trim();

  //these varibables keep user and computer choice with capital 1st letters
  var wordOutput = word.charAt(0).toUpperCase() + word.slice(1);
  var userChooseOutput =
    userChoose.charAt(0).toUpperCase() + userChoose.slice(1);

  //handle invalid responses from the user.
  if (userChoose == 0) { //if value is empty
    alert("Input is empty!");
    form.userChooseValue.focus();
    return false;
  } else if (
    // if user's input different than one of the 3 options send alert "Incorrect value!"
    userChoose != "rock" &&
    userChoose != "paper" &&
    userChoose != "scissors"
  ) {
    alert("Incorrect value!");
    form.userChooseValue.focus();
    return false;
  } else {
//print user's and computer's choose
    document.getElementById("compC").innerHTML =
      "Computer chooses: " + wordOutput;

    document.getElementById("playerC").innerHTML =
      "Player chooses: " + userChooseOutput;

//The html page displays a message indicating weather the user or the computer was the winner.
    if (userChoose == word) {//check if user and computer made same choose
      // getElementById method returns the elements that have the "result", "tie" or "won" attributes with the specified value.
      document.getElementById("result").innerHTML = "The result is a tie!";
      tie++;
      document.getElementById("tie").innerHTML = "Tie: " + tie;
      document.getElementById("won").innerHTML = "Tie!";
    } else if (
      //this else if statements provides main logic when user won
      (userChoose == "rock" && word == "scissors") ||
      (userChoose == "scissors" && word == "paper") ||
      (userChoose == "paper" && word == "rock")
    ) {
      // getElementById method returns the elements that have the "result", "tie" or "won" attributes with the specified value.
      document.getElementById("result").innerHTML = userChooseOutput + " wins!";
      userWinner++;
      document.getElementById("userWinner").innerHTML = "You won: " + userWinner;
      document.getElementById("won").innerHTML = "You won!";
    }
    else {//executes if computer won
      // getElementById method returns the elements that have the "result", "tie" or "won" attributes with the specified value.
      document.getElementById("result").innerHTML = wordOutput + " wins!";
      compWinner++;
      document.getElementById("compWinner").innerHTML = "Computer won: " + compWinner;
      document.getElementById("won").innerHTML = "Computer won!";
    }
  }
}
